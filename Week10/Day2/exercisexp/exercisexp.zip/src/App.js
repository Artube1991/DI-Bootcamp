import Todo from "./components/Todo";

function App() {
  return (
    <Todo />
  );
}

export default App;
